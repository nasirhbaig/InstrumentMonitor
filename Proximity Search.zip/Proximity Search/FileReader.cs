﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proximity_Search
{
    public static class FileReader
    {
        public static IEnumerable<string> ReadFile(string fileName)
        {
            if (!File.Exists(fileName))
                throw new ArgumentException($"File [{fileName}] couldn't be found. Please enter file name with correct path.");

            using (StreamReader reader = new StreamReader(fileName))
            {
                string str = string.Empty;
                int i = 0;
                while ((i = reader.Read()) != -1)
                {
                    char c = Convert.ToChar(i);
                    if (char.IsDigit(c) || char.IsLetter(c))
                    {
                        str += c;
                    }
                    else
                    {
                        if (str.Trim() != string.Empty)
                            yield return str;
                        str = string.Empty;
                    }
                }

                if(!string.IsNullOrEmpty(str))
                    yield return str;
            }
        }
    }
}
